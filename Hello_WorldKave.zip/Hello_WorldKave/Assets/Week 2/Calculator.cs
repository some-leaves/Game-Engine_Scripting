using UnityEngine;
using System;
using TMPro;

public class Calculator : MonoBehaviour
{
    //TODO: Create a TextMeshProUGUI variable here and assign it in the inspector

   public TextMeshProUGUI FirstText ;
  

    //TODO: Create a temporary float variable here called prevInput so we can store the previous input value
    //      when performaing calculations
    float prevInput;


    //TODO: Create a bool variable called clearPrevInput here so we can flip it to true/false if we should clear the prior input
    //      when typing in values. Example, if we type in the value 402 and then press the + button, the next value I enter
    //      should replace the 402 I previously entered

    bool clearPrevInput;

    //TODO: Leave this alone
    private EquationType equationType;

    private void Start()
    {
        Clear();
    }

    public void AddInput(string input)
    {
        //TODO: Check the clearPrevInput variable you created 
        //      and if true then set the current value of the text label to be string.Empty
        //      and set the clearPrevInput value to false

       if(clearPrevInput == true) // checking to see if its true; if clearInput bool is true 
       {
            //This will return the current string
            //clear the text and set it back to false
            
          
            FirstText.ToString(); // Returns this instance of String
            Clear(); // Clear the input
            clearPrevInput = false; // reset the bool to false
       }


        //TODO: Add the input passed into the AddInput function to the current value of the label
        // Hint. You can perform the + operations on string data to combine them
        // Whatever is in the label is the current value
        string currentValue = input + FirstText;
       // Debug.Log(input + FirstText);

      

  

    }

    public void SetEquationAsAdd()
    {
        //TODO: Store the current input value on the text label into the float variable you created.
        //      Hint. You will need to google float.Parse() and pass in the string value of the label.
        //TODO: Set the bool you made to true so that the next number that gets typed in clears the calculator display.
      //  prevInput = float.Parse(text.text);
        //clearPrevInput = true;
        equationType = EquationType.ADD;

       prevInput = float.Parse(FirstText.text);
        clearPrevInput = true;




    }

    //TODO: Create a SetEquationAsSubtract function similar to SetEquationAsAdd.
    //      Make sure you set equationType to EquationType.SUBTRACT
    public void SetEquationAsSubtract()
    {
        equationType = EquationType.SUBTRACT;
        prevInput = float.Parse(FirstText.text);
        clearPrevInput = true;


    }



    //TODO: Create a SetEquationAsMultiply function similar to SetEquationAsAdd.
    //      Make sure you set equationType to EquationType.Multiply
    public void EquationAsMultiply()
    {
        equationType = EquationType.MULTIPLY; // 
        prevInput = float.Parse(FirstText.text);
        clearPrevInput = true;

    }

    //TODO: Create a SetEquationAsDivide function similar to SetEquationAsAdd.
    //      Make sure you set equationType to EquationType.DIVIDE
    public void EquationAsDivide()
    {
        equationType = EquationType.DIVIDE; 
        prevInput = float.Parse(FirstText.text);
        clearPrevInput = true;

    }



    public void Add()
    {
        //TODO: Calculate the sum of the float variable that stores the previous input value and the current input value
        //Set the text label to display that sum

     // string  Sum = prevInput + ;

        Debug.Log(FirstText);
        
    }


    //TODO: Implement Subtract function
    public void Subtract()
    {

    }


    //TODO: Implement Multiply function
    public void Multiply()
    {

    }


    //TODO: Implement Divide function
    public void Divide()
    {

    }


    public void Clear()
    {
        //TODO: Reset the state of your calculator... reset the display value to a 0, reset the bool variable
        //      that represents if the display should be cleared to true, reset the temporary float variable as well to 0



        //TODO: Leave this alone
        equationType = EquationType.None;        
    }

    public void Calculate()
    {
        //TODO: Check if equationTypep is Add/Subtract/Multiply/Divide and call the correct function
        if (equationType == EquationType.ADD) Add();
    }

    //TODO: Leave this alone
    public enum EquationType
    {
        None = 0,
        ADD = 1,
        SUBTRACT = 2,
        MULTIPLY = 3,
        DIVIDE = 4
    }
}
