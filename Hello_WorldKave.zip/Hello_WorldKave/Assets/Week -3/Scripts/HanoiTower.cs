using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HanoiTower : MonoBehaviour
{
    [SerializeField] private Transform peg1Transform;
    [SerializeField] private Transform peg2Transform;
    [SerializeField] private Transform peg3Transform;


    [SerializeField] private int[] peg1 = { 1, 2, 3, 4 };//bigger number = bigger disk; smaller number = smaller disk
    [SerializeField] private int[] peg2 = { 0, 0, 0, 0 };
    [SerializeField] private int[] peg3 = { 0, 0, 0, 0 };

    [SerializeField] private int currentPeg = 1;
   
    [ContextMenu("Move Right")]
   public void MoveRight()
    {
        //make sure we aren't the right most peg
        if (CanMoveRight() == false) return;
        //check to see what index and number we are moving from this peg

        int[] fromArray = GetPeg(currentPeg);
        int fromIndex = GetTopNumberIndex(fromArray);

        if(fromIndex == -1) return;

        int[] toArray = GetPeg(currentPeg + 1);
        int toIndex = GetIndexOfFreeSlot(toArray);
        //if adjaceny peg is full then we cannot move anything into it
        //this probably eill never happen since the max number if numbers
        //we have is the size of the peg

        if (toIndex == -1) return;
        
        if (CanAddPeg(fromArray[fromIndex],toArray) == false) return;

        //prevent 2 being on top of 1
        //if all check pass then go ahead and move the number
        //out if this arraay into the adjacent array

        MoveNumber(fromArray, fromIndex, toArray, toIndex);

        Transform disc = PopDiscFromCurrentPeg();
        Transform toPeg = GetpegTransform(currentPeg + 1);

        disc.SetParent(toPeg); // make it an orphan then make it a child of other transform

        //move interface between pegs

    }

    Transform PopDiscFromCurrentPeg()
    {
        Transform CurrentPegTransform = GetpegTransform(currentPeg);
        int index = CurrentPegTransform.childCount - 1;
        Transform disk = CurrentPegTransform.GetChild(index);
        return disk;
    }
    Transform GetpegTransform(int pegNumber)
    {
        //alternative ways to find our peg
       if (pegNumber == 1) return peg1Transform;
        if (pegNumber == 1) return peg2Transform;
        
        return peg3Transform;
       // GameObject pegObject = GameObject.Find("Peg-" + pegNumber.ToString());
       // return pegObject.transform;
      // return GameObject.Find("peg-" + pegNumber.ToString()).transform;

    }
    [ContextMenu("Move Left")]
    public void MoveLeft()
    {
        if (CanMoveLeft() == false) return;

        int[] fromArray = GetPeg(currentPeg);
        int fromIndex = GetTopNumberIndex(fromArray);

        if (fromIndex == -1) return;

        //

        int[] toArray = GetPeg(currentPeg - 1);
        int toIndex = GetIndexOfFreeSlot(toArray);
        
        if (toIndex == -1) return;

        MoveNumber(fromArray, fromIndex, toArray, toIndex);

        Transform disc = PopDiscFromCurrentPeg();
        Transform toPeg = GetpegTransform(currentPeg - 1);

        disc.SetParent(toPeg); // make it an orphan then make it a child of other transform



    }


    public void IcrementPegNumber()
    {
        currentPeg++;
    }


    public void DecrementPegNumber()
    {
        currentPeg--;

    }



    void MoveNumber(int[] fromArr, int fromIndex, int[] toArr, int toIndex)
    {
        int value = fromArr[fromIndex];
        fromArr[fromIndex] = 0;

        toArr[toIndex] = value;
    }

    bool CanMoveRight()
    {
        //If peg 1 or 2 then can move right
        return currentPeg < 3;
    }

    bool CanAddPeg(int value, int[] peg)
    {
        int topNumberIndex = GetTopNumberIndex(peg);

        if (topNumberIndex == -1) return true;

        int topNumber = peg[topNumberIndex];
        return topNumber > value;// if it more than the value its bad. 
    }
   

    bool CanMoveLeft()
    {
        //If peg 2 or 3 then can move right
        return currentPeg > 1;
    }

    int[] GetPeg(int pegNumber)
    {
        if(pegNumber == 1) return peg1;
       
        if(pegNumber == 2) return peg2; 
        
        return peg3;
    }

    int GetTopNumberIndex(int[] peg)
    {
        for(int i = 0; i < peg.Length; i++)
        {
            if (peg[i] != 0) return i;
        }

        return -1;
    }

    int GetIndexOfFreeSlot(int[] peg)
    {
        for (int i = peg.Length - 1; i >= 0; i--)
        {
            if (peg[i] == 0) return i; // if element is 0 it will return the index it is a free slot
        }

        return -1;
    }
}
